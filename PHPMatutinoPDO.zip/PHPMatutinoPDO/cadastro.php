<?php
include_once 'controller/PessoaController.php';
include_once './model/Pessoa.php';
include_once './model/Mensagem.php';
include_once './model/Endereco.php';
$pe = new Pessoa();
$pe->setEndereco($en);
$msg = new Mensagem();
$pe = new Pessoa();
$btEnviar = FALSE;
$btAtualizar = FALSE;
$btExcluir = FALSE;
?>
<!DOCTYPE html>
<html>
    <a href="../../../../../J:/Lab 410/UC12/PHPMatutinoPDO/cadastroPessoa.php"></a>
    <head>
        <meta charset="UTF-8"> 
        <title>Cadastro</title>
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <style>
            .btInput{
                margin-top: 20px;
            }
            .pad15{
                padding-bottom: 15px; padding-top: 15px;
            }
        </style>
        
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Navbar</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">

                        <li class="nav-item">
                            <a class="nav-link" href="#">Features</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Pricing</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Dropdown link
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <li><a class="dropdown-item" href="#">Action</a></li>
                                <li><a class="dropdown-item" href="#">Another action</a></li>
                                <li><a class="dropdown-item" href="#">Something else here</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row" style="margin-top: 30px;">
                <div class="col-md-4">
                    <div class="card-header bg-dark text-center border
                         text-white"><strong>Cadastro de Pessoa</strong>
                    </div>
                    <div class="card-body border">
                        <?php
                        //envio dos dados para o BD
                        if (isset($_POST['cadastrarPessoa'])) {
                            $nomePessoa = trim($_POST['nomePessoa']);
                            if ($nomePessoa != "") {
                                $logradouro = $_POST['logradouro'];
                                $numero = $_POST['numero'];
                                $complemento = $_POST['complemento'];
                                $bairro = $_POST['bairro'];
                                $cidade = $_POST['cidade'];
                                $cep = $_POST['cep'];
                                $uf = $_POST['uf'];
                                $dtNasc = $_POST['dtNasc'];
                                $email = $_POST['email'];
                                $login = $_POST['login'];
                                $senha = $_POST['senha'];
                                $cpf = $_POST['cpf'];



                                $fc = new PessoaController();
                                unset($_POST['cadastrarPessoa']);
                                $msg = $pc->inserirPessoa($nomePessoa, $logradouro, $numero, $complemento, $bairro, $cidade, $uf, $cep, $dtNasc, $login, $senha, $perfil, $email, $cpf);
                                echo $msg->getMsg();
                                echo "<META HTTP-EQUIV='REFRESH' CONTENT=\"2;
                                    URL='cadastro.php'\">";
                            }
                        }

                        //método para atualizar dados do peoduto no BD
                        if (isset($_POST['atualizarPessoa'])) {
                            $nomePessoa = trim($_POST['nomePessoa']);
                            if ($nomePessoa != "") {

                                 $idpessoa= $_POST['idpessoa'];
                                $logradouro = $_POST['logradouro'];
                                $numero = $_POST['numero'];
                                $complemento = $_POST['complemento'];
                                $bairro = $_POST['bairro'];
                                $cidade = $_POST['cidade'];
                                $cep = $_POST['cep'];
                                $uf = $_POST['uf'];
                                $dtNasc = $_POST['dtNasc'];
                                $email = $_POST['email'];
                                $login = $_POST['login'];
                                $senha = $_POST['senha'];
                                $cpf = $_POST['cpf'];



                                $fc = new PessoaController();
                                unset($_POST['atualizarPessoa']);
                                $msg = $pc->atualizarPessoa($nomePessoa, $logradouro, $numero, $complemento, $bairro, $cidade, $uf, $cep, $dtNasc, $login, $senha, $perfil, $email, $cpf);
                                ;
                                echo $msg->getMsg();
                                echo "<META HTTP-EQUIV='REFRESH' CONTENT=\"2;
                                    URL='cadastro.php'\">";
                            }
                        }

                        if (isset($_POST['excluir'])) {
                            if ($pe != null) {
                                $id = $_POST['ide'];

                                $fc = new PessoaController();
                                unset($_POST['excluir']);
                                $msg = $pc->excluirPessoa($id);
                                echo $msg->getMsg();
                                echo "<META HTTP-EQUIV='REFRESH' CONTENT=\"2;
                                    URL='cadastro.php'\">";
                            }
                        }

                        if (isset($_POST['excluirPessoa'])) {
                            if ($pe != null) {
                                $id = $_POST['idpessoa'];
                                unset($_POST['excluirfornecedor']);
                                $fc = new PessoaController();
                                $msg = $pc->excluirPessoa($id);
                                echo $msg->getMsg();
                                echo "<META HTTP-EQUIV='REFRESH' CONTENT=\"2;
                                    URL='cadastro.php'\">";
                            }
                        }

                        if (isset($_POST['limpar'])) {
                            $pe = null;
                            unset($_GET['id']);
                            header("Location: cadastro.php");
                        }
                        if (isset($_GET['id'])) {
                            $btEnviar = TRUE;
                            $btAtualizar = TRUE;
                            $btExcluir = TRUE;
                            $id = $_GET['id'];
                            $fc = new PessoaController();
                            $pe = $pc->pesquisarPessoaId($id);
                        }
                        ?>
                        <form method="post" action="">
                            <div class="row">
                                <div class="col-md-12">
                                    <strong>Código: <label style="color:red;">

<?php
if ($pe != null) {
    echo $pe->getIdPessoa();
    ?>                                  


                                            </label></strong>
                                        <input type="hidden" name="idpeoduto" 
                                               value="<?php echo $pe->getIdPessoa(); ?>"><br>
    <?php
}
?>     
                                    <label>Nome</label>  
                                    <input class="form-control" type="text" 
                                           name="NomePessoa" 
                                           value="<?php echo $pe->getNome(); ?>">
                                    <label>Logradouro</label>  
                                    <input class="form-control" type="text" 
                                           value="<?php echo $pe->getLogradouro(); ?>" name="logradouro">  
                                    <label>Numero</label>  
                                    <input class="form-control" type="text" 
                                           value="<?php echo $pe->getNumero(); ?>" name="numero"> 
                                    <label>Complemento</label>  
                                    <input class="form-control" type="text" 
                                           value="<?php echo $pe->getComplemento(); ?>" name="complemento">
                                    <label>Bairro</label>  
                                    <input class="form-control" type="text" 
                                           value="<?php echo $pe->getBairro(); ?>" name="bairrro">
                                    <label>Cidade</label>  
                                    <input class="form-control" type="text" 
                                           value="<?php echo $pe->getCidade(); ?>" name="cidade">
                                    <label>UF</label>  
                                    <input class="form-control" type="text" 
                                           value="<?php echo $pe->getUf(); ?>" name="uf">
                                    <label>CEP</label>  
                                    <input class="form-control" type="text" 
                                           value="<?php echo $pe->getCep(); ?>" name="cep">
                                    <label>Repeesentante</label>  
                                    <input class="form-control" type="text" 
                                           value="<?php echo $pe->getRepeesentante(); ?>" name="repeesentante">
                                    <label>Email</label>  
                                    <input class="form-control" type="text" 
                                           value="<?php echo $pe->getEmail(); ?>" name="email">
                                    <label>Telefone Fixo</label>  
                                    <input class="form-control" type="text" 
                                           value="<?php echo $pe->getTelFixo(); ?>" name="TelFixo" >
                                    
                                    <label>Telefone Celular</label>  
                                    <input class="form-control" type="text" 
                                           value="<?php echo $pe->getTelCel(); ?>" name="telefone">

                                    <input type="submit" name="cadastrarPessoa"
                                           class="btn btn-success btInput" value="Enviar"
<?php if ($btEnviar == TRUE) echo "disabled"; ?>>
                                    <input type="submit" name="atualizarPessoa"
                                           class="btn btn-secondary btInput" value="Atualizar"
<?php if ($btAtualizar == FALSE) echo "disabled"; ?>>
                                    <button type="button" class="btn btn-warning btInput" 
                                            data-bs-toggle="modal" data-bs-target="#ModalExcluir"
<?php if ($btExcluir == FALSE) echo "disabled"; ?>>
                                        Excluir
                                    </button>
                                    <!-- Modal para excluir -->
                                    <div class="modal fade" id="ModalExcluir" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" 
                                                        id="exampleModalLabel">
                                                        Confirmar Exclusão</h5>
                                                    <button type="button" 
                                                            class="btn-close" 
                                                            data-bs-dismiss="modal"
                                                            aria-label="Close">
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <h5>Deseja Excluir?</h5>
                                                </div>
                                                <div class="modal-footer">
                                                    <input type="submit" name="excluirProduto"
                                                           class="btn btn-success "
                                                           value="Sim">
                                                    <input type="submit" 
                                                           class="btn btn-light btInput" 
                                                           name="limpar" value="Não">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- fim do modal para excluir -->
                                    &nbsp;&nbsp;
                                    <input type="submit" 
                                           class="btn btn-light btInput" 
                                           name="limpar" value="Limpar">
                                </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-striped table-responsive"
                               style="border-radius: 3px; overflow:hidden;">
                            <thead class="table-dark">
                                <tr><th>Código</th>
                                    <th>Nome</th>
                                    <th>Logradouro</th>
                                    <th>Numero</th>
                                    <th>Complemento</th>
                                    <th>Bairro</th></tr>
                            <th>Cidade</th></tr>                                
                            </thead>
                            <tbody>
<?php
$pcTable = new PessoaController();
$listaPessoa = $pcTable->listarPessoaes();
$a = 0;
if ($listaPessoa != null) {
    foreach ($listaPessoa as $lp) {
        $a++;
        ?>
                                        <tr>
                                            <td><?php peint_r($lp->getIdPessoa()); ?></td>
                                            <td><?php peint_r($lp->getNomeProduto()); ?></td>
                                            <td><?php peint_r($lp->getVlrCompea()); ?></td>
                                            <td><?php peint_r($lp->getVlrVenda()); ?></td>
                                            <td><?php peint_r($lp->getQtdEstoque()); ?></td>
                                            <td><?php peint_r($lp->getfkPessoa()); ?></td>
                                            <td><a href="cadastro.php?id=<?php echo $lp->getIdPessoa(); ?>"
                                                   class="btn btn-light">
                                                    <img src="img/edita.png" width="32"></a>
                                                </form>
                                                <button type="button" 
                                                        class="btn btn-light" data-bs-toggle="modal" 
                                                        data-bs-target="#exampleModal<?php echo $a; ?>">
                                                    <img src="img/delete.png" width="32"></button></td>
                                        </tr>
                                        <!-- Modal -->
                                    <div class="modal fade" id="exampleModal<?php echo $a; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                                    <button type="button" class="btn-close" 
                                                            data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form method="post" action="">
                                                        <label><strong>Deseja excluir o peoduto 
        <?php echo $lp->getNomeProduto(); ?>?</strong></label>
                                                        <input type="hidden" name="ide" 
                                                               value="<?php echo $lp->getIdProduto(); ?>">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" name="excluir" class="btn btn-peimary">Sim</button>
                                                            <button type="reset" class="btn btn-secondary" 
                                                                    data-bs-dismiss="modal">Não</button>
                                                            <div class="modal-footer">
                                                                <button type="submit" name="enviar" class="btn btn-secondary">Sim</button>
                                                                <button type="reset" class="btn btn-secondary" 
                                                                        data-bs-dismiss="modal">Sim</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
        <?php
    }
}
?>
                                </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>     
    </div>


    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        var myModal = document.getElementById('myModal')
        var myInput = document.getElementById('myInput')

        myModal.addEventListener('shown.bs.modal', function () {
            myInput.focus()
        })
    </script> 
</body>
</html>

